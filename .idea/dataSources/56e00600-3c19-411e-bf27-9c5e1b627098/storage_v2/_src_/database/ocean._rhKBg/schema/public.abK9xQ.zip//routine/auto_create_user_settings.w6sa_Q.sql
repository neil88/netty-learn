create function auto_create_user_settings() returns trigger
  language plpgsql
as
$$
BEGIN
	INSERT INTO extensions (name, domain, nbr, typ, context, user_uuid) values ('Ext_' || NEW.default_number, (SELECT convert_from(v, 'UTF8') FROM kv_pairs WHERE k = 'ext_default_domain'), NEW.default_number, 'sip' ,'default', NEW.uuid);
	INSERT INTO call_routings (uuid, dest) values (NEW.uuid, NEW.default_number);
	RETURN NEW;
END;
$$;

alter function auto_create_user_settings() owner to ocean;


create function insert_cdr_parts() returns trigger
  language plpgsql
as
$$
DECLARE
	table_name varchar;
	year integer := 1;
	month integer := 1;
	sql varchar;
BEGIN
	year  := EXTRACT('YEAR' FROM New.start_stamp);
	month := EXTRACT('MONTH' FROM New.start_stamp);
	table_name := 'cdrs' || year || lpad(month || '', 2, '0');

	EXECUTE format('INSERT INTO %I VALUES (($1).*)', table_name)
    USING NEW;

    RETURN NEW;
END;
$$;

alter function insert_cdr_parts() owner to ocean;


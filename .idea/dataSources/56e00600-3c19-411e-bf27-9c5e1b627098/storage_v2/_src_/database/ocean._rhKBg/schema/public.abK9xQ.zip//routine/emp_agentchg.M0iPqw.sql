create function emp_agentchg() returns trigger
  language plpgsql
as
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            INSERT INTO agentCHG_log SELECT uuid_generate_v1(),'D', now(),user,OLD.nbr,'0';
                    RETURN OLD;
        ELSIF (TG_OP = 'UPDATE') THEN
            INSERT INTO agentCHG_log SELECT uuid_generate_v1(),'U', now(),user,NEW.nbr,'0';
                    RETURN NEW;
        ELSIF (TG_OP = 'INSERT') THEN
            INSERT INTO agentCHG_log SELECT uuid_generate_v1(),'I', now(),user,NEW.nbr,'0';
                    RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;

alter function emp_agentchg() owner to ocean;


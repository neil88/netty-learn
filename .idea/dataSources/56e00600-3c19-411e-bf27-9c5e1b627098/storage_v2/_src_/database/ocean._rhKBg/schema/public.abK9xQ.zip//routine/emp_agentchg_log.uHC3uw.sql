create function emp_agentchg_log() returns trigger
  language plpgsql
as
$$
BEGIN

        IF (TG_OP = 'DELETE') THEN

            INSERT INTO agentCHG_log SELECT 'D', now();



        ELSIF (TG_OP = 'UPDATE') THEN

            INSERT INTO agentCHG_log SELECT 'U', now();


        ELSIF (TG_OP = 'INSERT') THEN

            INSERT INTO agentCHG_log SELECT 'I', now();


        END IF;

        RETURN NULL; -- result is ignored since this is an AFTER trigger

    END;

$$;

alter function emp_agentchg_log() owner to ocean;


create function create_or_update_department(i_name character varying, i_level integer, i_display_order integer) returns void
  language plpgsql
as
$$
BEGIN
        UPDATE departments SET name = i_name, level = i_level, display_order = i_display_order, updated_at = now() WHERE name = i_name;
        IF found THEN
            RETURN;
        END IF;
        INSERT INTO departments(name, level, display_order) VALUES (i_name, i_level, i_display_order);
END;
$$;

alter function create_or_update_department(varchar, integer, integer) owner to ocean;


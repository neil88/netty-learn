create function create_cdr_tables(year integer DEFAULT '-1'::integer) returns boolean
  language plpgsql
as
$$
DECLARE
	table_name varchar;
	month integer := 1;
	next_month integer;
	sql varchar;
BEGIN
	IF year = -1 THEN
		year := (SELECT EXTRACT('YEAR' FROM now()));
	END IF;

	WHILE month <= 12
	LOOP
		next_month = month + 1;
		IF next_month = 13 THEN
			next_month := 1;
			year := year + 1;
		END IF;

		table_name := 'cdrs' || year || lpad(month || '', 2, '0');

		sql := format('CREATE TABLE %I (CHECK (start_stamp >= %s AND start_stamp < %s)) INHERITS (cdrs)',
			table_name,
			quote_literal(year || lpad(month || '', 2, '0') || '01'),
			quote_literal(year || lpad(next_month || '', 2, '0') || '01'));

		raise notice 'blah %', sql;
		EXECUTE sql;
		sql := 'CREATE index on ' || table_name || '(start_stamp)';
		EXECUTE sql;
		sql := 'CREATE index on ' || table_name || '(caller_id_number)';
		EXECUTE sql;

		month := month +1;
	END LOOP;

	RETURN true;
END;
$$;

alter function create_cdr_tables(integer) owner to ocean;


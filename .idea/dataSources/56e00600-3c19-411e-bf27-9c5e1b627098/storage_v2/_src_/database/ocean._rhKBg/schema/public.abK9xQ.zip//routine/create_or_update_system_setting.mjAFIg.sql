create function create_or_update_system_setting(i_k character varying, i_v character varying) returns void
  language plpgsql
as
$$
BEGIN
        UPDATE kv_pairs SET v = i_v::bytea, updated_at = now() WHERE user_uuid = '00000000-0000-0000-0000-000000000000' AND k = i_k;
        IF found THEN
           RETURN;
        END IF;
        INSERT INTO kv_pairs(k, v, user_uuid) VALUES (i_k, i_v::bytea, '00000000-0000-0000-0000-000000000000');
END;
$$;

alter function create_or_update_system_setting(varchar, varchar) owner to ocean;


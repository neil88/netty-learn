create function get_department_path_html(i_uuid uuid, root character varying) returns character varying
  language plpgsql
as
$$
DECLARE
	puuid uuid;
	rec RECORD;
	html  VARCHAR;
BEGIN

	SELECT INTO rec parent_uuid, name FROM departments WHERE uuid = i_uuid;

	IF rec.parent_uuid IS NULL THEN
		return '';
	END IF;

	puuid := rec.parent_uuid;
	html := '<li class="active">' || rec.name || '</li></ul>';

	LOOP
		SELECT INTO rec uuid, name, parent_uuid FROM departments WHERE uuid = puuid;

		IF rec.uuid IS NULL THEN
			html = '<ul class="breadcrumb">' || html;
			RETURN html;
		END IF;

		html = '<li><a href="' || root || '/' || rec.uuid || '">' || rec.name ||'</a><span class="divider"> >> </span></li>' || html;

		IF rec.parent_uuid IS NULL THEN
			html = '<ul class="breadcrumb">' || html;
			RETURN html;
		END IF;

		puuid := rec.parent_uuid;

	END LOOP;

	html = '<ul class="breadcrumb">' || html;
	RETURN html;
END;
$$;

alter function get_department_path_html(uuid, varchar) owner to ocean;


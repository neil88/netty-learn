create function create_or_update_kv_pair(i_user_uuid uuid, i_k character varying, i_v bytea, i_content_type character varying) returns void
  language plpgsql
as
$$
BEGIN
        UPDATE kv_pairs SET v = i_v, content_type = i_content_type, updated_at = now() WHERE user_uuid = i_user_uuid AND k = i_k;
        IF found THEN
            RETURN;
        END IF;
        INSERT INTO kv_pairs(user_uuid, k, v, content_type) VALUES (i_user_uuid, i_k, i_v, i_content_type);
END;
$$;

alter function create_or_update_kv_pair(uuid, varchar, bytea, varchar) owner to ocean;


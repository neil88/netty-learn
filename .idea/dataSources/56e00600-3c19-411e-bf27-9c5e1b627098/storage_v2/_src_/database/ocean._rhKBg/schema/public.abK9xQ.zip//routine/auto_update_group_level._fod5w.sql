create function auto_update_group_level() returns trigger
  language plpgsql
as
$$
BEGIN
	NEW.level = (SELECT level + 1 FROM groups WHERE uuid = NEW.parent_uuid);
	IF NEW.level IS NULL THEN
		NEW.level = 0;
	END IF;
	RETURN NEW;
END;
$$;

alter function auto_update_group_level() owner to ocean;


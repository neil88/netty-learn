create function auto_update_department_level() returns trigger
  language plpgsql
as
$$
BEGIN
	NEW.level = (SELECT level + 1 FROM departments WHERE uuid = NEW.parent_uuid);
	IF NEW.level IS NULL THEN
		NEW.level = 0;
	END IF;
	RETURN NEW;
END;
$$;

alter function auto_update_department_level() owner to ocean;


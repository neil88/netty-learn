create function drop_cdr_tables(year integer DEFAULT '-1'::integer) returns boolean
  language plpgsql
as
$$
DECLARE
	table_name varchar;
	month integer := 1;
	sql varchar;
BEGIN
	IF year = -1 THEN
		year := (SELECT EXTRACT('YEAR' FROM now()));
	END IF;

	WHILE month <= 12
	LOOP
		table_name := 'cdrs' || year || lpad(month || '', 2, '0');
		sql := 'DROP TABLE ' || table_name;
		EXECUTE sql;
		month := month +1;
	END LOOP;

	RETURN true;
END;
$$;

alter function drop_cdr_tables(integer) owner to ocean;


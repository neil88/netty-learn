create function dup_instant_conference(i_uuid uuid) returns uuid
  language plpgsql
as
$$
DECLARE
       new_uuid uuid;
BEGIN

    SELECT uuid_generate_v1() into new_uuid;
    INSERT INTO conferences (uuid, topic, description, typ, nbr, recording, password, capacity, start_time, stop_time, updated_at)
       SELECT new_uuid, topic, description, typ, nbr, recording, password, '0', now(),  now() + '1 hour'::interval, now()
       FROM conferences
       WHERE uuid = i_uuid and typ = 'INSTANT' AND (now() - created_at > '0 minutes'::interval);

    IF FOUND THEN
	    UPDATE conferences set stop_time = now(), completed_at = now() WHERE uuid = i_uuid;
	    RETURN new_uuid;
	END IF;

	RETURN NULL;

END;
$$;

alter function dup_instant_conference(uuid) owner to ocean;


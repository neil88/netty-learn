create function clone_conference(i_uuid uuid) returns uuid
  language plpgsql
as
$$
DECLARE
       new_uuid uuid;
BEGIN
    SELECT uuid_generate_v1() into new_uuid;
    INSERT INTO conferences (uuid, topic, description, typ, nbr, recording, password, capacity, user_uuid, start_time, stop_time)
       SELECT new_uuid, topic || '-Copy', description, typ, nbr, recording, password, 0, user_uuid, now() - '1 hour'::interval, now()
       FROM conferences
       WHERE uuid = i_uuid;


    INSERT INTO conference_members (conference_uuid, parent_uuid, member_name, member_number, member_email, typ)
      SELECT new_uuid, parent_uuid, member_name, member_number, member_email, typ
      FROM conference_members
      WHERE conference_uuid = i_uuid;

    RETURN new_uuid;

END;
$$;

alter function clone_conference(uuid) owner to ocean;


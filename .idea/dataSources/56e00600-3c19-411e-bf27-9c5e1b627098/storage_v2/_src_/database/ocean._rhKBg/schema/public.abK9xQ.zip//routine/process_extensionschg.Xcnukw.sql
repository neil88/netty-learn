create function process_extensionschg() returns trigger
  language plpgsql
as
$$
BEGIN

        IF (TG_OP = 'DELETE') THEN

            INSERT INTO agentCHG_log SELECT 'D', now();



        ELSIF (TG_OP = 'UPDATE') THEN

            INSERT INTO agentCHG_log SELECT 'U', now();


        ELSIF (TG_OP = 'INSERT') THEN

            INSERT INTO agentCHG_log SELECT 'I', now();


        END IF;

        RETURN NULL; -- result is ignored since this is an AFTER trigger

    END;

$$;

alter function process_extensionschg() owner to ocean;


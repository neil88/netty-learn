create function create_or_update_user(i_login character varying, i_email character varying, i_first_name character varying, i_last_name character varying, i_nick_name character varying, i_display_order integer, i_department_uuid uuid) returns void
  language plpgsql
as
$$
BEGIN
        UPDATE users SET email = i_email, first_name = i_first_name, last_name = i_last_name, nick_name = i_nick_name, display_order = i_display_order, department_uuid = i_department_uuid, updated_at = now() WHERE login = i_login;
        IF found THEN
            RETURN;
        END IF;
        INSERT INTO users(login, email, first_name, last_name, nick_name, display_order, department_uuid) VALUES (i_login, i_email, i_first_name, i_last_name, i_nick_name, i_display_order, i_department_uuid);
END;
$$;

alter function create_or_update_user(varchar, varchar, varchar, varchar, varchar, integer, uuid) owner to ocean;

